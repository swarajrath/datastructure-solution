const calculateCo2 = require('./index')

test('Show correct for Medium Diesel Car', () => {
    expect(calculateCo2(15, 'medium-diesel-car', 'km', 'kg')).toBe(2.6)
})
test('Show correct for Large Petrol Cars', () => {
    expect(calculateCo2(1800.5, 'large-petrol-car', undefined,'kg')).toBe(507.7)
})
test('Show correct for Train', () => {
    expect(calculateCo2(14500, 'train', 'm')).toBe(87)
})
test('Show correct for Train', () => {
    expect(calculateCo2(14500, 'train', 'm', 'kg')).toBe(0.1)
})

// Some extra unit testing
test('Show correct for Large Petrol Car', () => {
    expect(calculateCo2(127, 'large-petrol-car', 'km', 'kg')).toBe(35.8)
})
test('Show correct for Small Plugin Hybrid Car', () => {
    expect(calculateCo2(29, 'small-plugin-hybrid-car', 'km', 'g')).toBe(2117)
})
