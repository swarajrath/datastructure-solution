const yargs = require('yargs')

var distance = yargs.argv.distance;
var transportation = yargs.argv.transportationMethod;

if (yargs.argv.unitOfDistance) {
    var distanceUnit = yargs.argv.unitOfDistance;
}
if (yargs.argv.output) {
    var output = yargs.argv.output;
}

function calculateCo2(distance, transportation, distanceUnit, output) {
    var co2Emission
    if (distanceUnit == 'm') {
        distance = distance / 1000
    }
    switch (transportation) {
        case 'small-diesel-car':
            co2Emission = distance * 142
            break;
        case 'small-petrol-car':
            co2Emission = distance * 154
            break;
        case 'small-plugin-hybrid-car':
            co2Emission = distance * 73
            break;
        case 'small-electric-car':
            co2Emission = distance * 50
            break;
        case 'medium-diesel-car':
            co2Emission = distance * 171
            break;
        case 'medium-petrol-car':
            co2Emission = distance * 192
            break;
        case 'medium-plugin-hybrid-car':
            co2Emission = distance * 110
            break;
        case 'medium-electric-car':
            co2Emission = distance * 58
            break;
        case 'large-diesel-car':
            co2Emission = distance * 209
            break;
        case 'large-petrol-car':
            co2Emission = distance * 282
            break;
        case 'large-plugin-hybrid-car':
            co2Emission = distance * 126
            break;
        case 'large-electric-car':
            co2Emission = distance * 73
            break;
        case 'bus':
            co2Emission = distance * 27
            break;
        case 'train':
            co2Emission = distance * 6
            break;

        default:
            console.log('Your vehicle is currently not on our list')
            break;
    }

    if (output == 'kg') {
        co2Emission = co2Emission / 1000
    } else {
        output = 'g'
    }
    co2Emission = Math.round((co2Emission + Number.EPSILON) * 10) / 10

    if (co2Emission) {
        console.log(`Your trip caused ${co2Emission}${output} of CO2-equivalent.`)
    } else {
        console.log('Your trip caused 0 CO2-equivalent.')
    }
    return co2Emission
}

// console.log(distance, distanceUnit, transportation, output)
calculateCo2(distance, transportation, distanceUnit, output)

module.exports = calculateCo2